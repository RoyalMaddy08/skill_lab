
void Timer0_Delay100us(unsigned long u32CNT);
void Timer0_Delay1ms(unsigned long u32CNT);
void Timer1_Delay10ms(unsigned long u32CNT);
void Timer2_Delay500us(unsigned long u32CNT);
void Timer3_Delay100ms(unsigned long u32CNT);

void Timer0_Delay40ms(unsigned long u32CNT);
void Timer3_Delay10us(unsigned long u32CNT);
