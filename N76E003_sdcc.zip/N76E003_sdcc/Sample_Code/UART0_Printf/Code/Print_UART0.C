/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2017 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Jan/21/2017
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E003 GPIO demo code
//***********************************************************************************************************
#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "Common.h"
#include "Delay.h"
#include <stdio.h>



/*==========================================================================*/
void main (void)
{
        unsigned int value;
		InitialUART0_Timer3(9600);
        TI = 1;															// Important, use prinft function must set TI=1;
        Enable_ADC_AIN4;
        printf("\n Hello world");
		while(1)
		{
            clr_ADCF;
			set_ADCS;									// ADC start trig signal
            while(ADCF == 0);
			value =ADCRH;
			value =value <<8;
			value |=ADCRL;
			printf ("\n Value = %d",value);

			Timer0_Delay1ms(100);
			//printf("\n Hello world");
			//Timer0_Delay1ms(300);
		}
}
